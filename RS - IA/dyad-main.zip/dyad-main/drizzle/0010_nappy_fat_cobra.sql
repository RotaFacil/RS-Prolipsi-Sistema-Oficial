ALTER TABLE `apps` ADD `install_command` text;--> statement-breakpoint
ALTER TABLE `apps` ADD `start_command` text;
