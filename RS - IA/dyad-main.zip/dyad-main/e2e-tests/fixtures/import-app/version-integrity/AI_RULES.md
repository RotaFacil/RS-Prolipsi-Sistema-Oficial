avoid AI_RULES auto-prompt
