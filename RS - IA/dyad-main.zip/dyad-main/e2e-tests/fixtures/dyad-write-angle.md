BEFORE TAG
<dyad-write path="src/foo/bar.tsx" description="page to use <a> and <b> tags.">
// BEGINNING OF FILE
</dyad-write>
AFTER TAG
