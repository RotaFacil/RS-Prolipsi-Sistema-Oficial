No description!

<dyad-execute-sql>
DROP TABLE users;
</dyad-execute-sql>

Done.
