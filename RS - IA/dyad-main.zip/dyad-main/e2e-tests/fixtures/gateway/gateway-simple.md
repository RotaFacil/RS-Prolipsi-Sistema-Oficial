Simple-response-from-gateway
