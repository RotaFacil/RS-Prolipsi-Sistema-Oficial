This is a simple basic response
