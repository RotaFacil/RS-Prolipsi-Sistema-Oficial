<dyad-rename from="src/App.tsx" to="src/Renamed.tsx">
</dyad-rename>

<dyad-write path="src/Renamed.tsx">
// newly added content to renamed file should exist
</dyad-write>
